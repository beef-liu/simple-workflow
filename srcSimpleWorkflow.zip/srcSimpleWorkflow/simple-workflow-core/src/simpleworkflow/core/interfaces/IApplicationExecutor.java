package simpleworkflow.core.interfaces;

import simpleworkflow.core.WorkflowException;
import simpleworkflow.core.meta.Application;

/**
 * @author XingGu_Liu
 */
public interface IApplicationExecutor {

    public Object executeApplication(Application appMeta) throws WorkflowException;

}
