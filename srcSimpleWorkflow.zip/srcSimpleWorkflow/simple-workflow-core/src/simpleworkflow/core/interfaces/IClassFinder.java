package simpleworkflow.core.interfaces;

/**
 * @author XingGu_Liu
 */
public interface IClassFinder {
    public Class<?> findClass(String var1) throws ClassNotFoundException;
}
