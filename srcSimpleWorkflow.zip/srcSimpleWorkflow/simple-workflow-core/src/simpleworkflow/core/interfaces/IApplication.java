package simpleworkflow.core.interfaces;

/**
 * @author XingGu_Liu
 */
public interface IApplication {

    public void init();

    public void destroy();

}
