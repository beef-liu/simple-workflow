package simpleworkflow.core;

/**
 * @author XingGu_Liu
 */
public class WorkflowException extends Exception {
}
