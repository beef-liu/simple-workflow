package simpleworkflow.core.persistence;

import simpleworkflow.core.WorkflowException;

/**
 * @author XingGu_Liu
 */
public class WorkflowPersistenceException extends WorkflowException {
}
