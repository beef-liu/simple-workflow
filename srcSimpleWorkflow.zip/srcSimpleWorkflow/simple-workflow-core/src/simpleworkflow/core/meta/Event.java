package simpleworkflow.core.meta;

/**
 * @author XingGu_Liu
 */
public class Event extends MetaBaseData {
}
